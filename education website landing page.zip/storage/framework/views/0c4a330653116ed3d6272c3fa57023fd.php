<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Auth System</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@200;400;600&family=Jost:wght@300;400;500;600;700&family=Outfit:wght@100&display=swap"
        rel="stylesheet">
    <script src="<?php echo e(asset('js/tailwindcss.3.4.1')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery.dataTables.min.css')); ?>">
    <?php echo $__env->yieldContent('css_content'); ?>

    <style>
        * {
            font-family: 'Inter', sans-serif;
            font-family: 'Jost', sans-serif;
            font-family: 'Outfit', sans-serif;
        }
    </style>
</head>

<body>
    <?php echo $__env->make('Layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('auth_content'); ?>


    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <?php echo $__env->yieldContent('script_content'); ?>
</body>

</html>
<?php /**PATH C:\Users\Tahsin Abrar\Downloads\education website landing page\resources\views/Layout/app.blade.php ENDPATH**/ ?>