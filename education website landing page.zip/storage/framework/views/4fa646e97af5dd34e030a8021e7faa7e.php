
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('Layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div style="height: 100vh;display: flex; align-items: center; justify-content: center;">
        <div style="width: 900px">

            <h1 class="text-3xl font-bold mb-4 text-center">Create Your <br />Own identity</h1>

            <?php if(session('success')): ?>
                <p class="text-green-600 text-center"><?php echo e(session('success')); ?></p>
                <p class="text-center">
                    <a target="_blank" class="text-blue-500 font-bold hover:text-blue-700 no-underline" href="<?php echo e(session('created_router')); ?>">Click ME</a>
                </p>
            <?php endif; ?>
            <?php $__errorArgs = ['router'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: red; text-align: center"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <form action="<?php echo e(route('resources.store')); ?>" method="post"
                class="max-w-md mx-auto bg-white p-6 rounded-md shadow-md">
                <?php echo csrf_field(); ?>

                <div class="mb-4">
                    <label for="router" class="block text-sm font-medium text-gray-600">Router:</label>
                    <input type="text" name="router" id="router" required placeholder="Enter Router | example 'home'"
                        class="mt-1 p-2 w-full border border-gray-300 rounded-md focus:outline-none focus:ring focus:border-blue-300">
                </div>

                <div class="mb-4">
                    <label for="html" class="block text-sm font-medium text-gray-600">HTML:</label>
                    <textarea name="html" id="html" required placeholder="Enter HTML | Not using 'body' tag"
                        class="mt-1 p-2 w-full border border-gray-300 rounded-md focus:outline-none focus:ring focus:border-blue-300"></textarea>
                </div>

                <div class="mb-4">
                    <label for="css" class="block text-sm font-medium text-gray-600">CSS:</label>
                    <textarea name="css" id="css" required placeholder="Enter CSS | Not using 'style' tag"
                        class="mt-1 p-2 w-full border border-gray-300 rounded-md focus:outline-none focus:ring focus:border-blue-300"></textarea>
                </div>

                <div class="mb-4">
                    <label for="script" class="block text-sm font-medium text-gray-600">Script:</label>
                    <textarea name="script" id="script" required placeholder="Enter Script | Not using 'script' tag"
                        class="mt-1 p-2 w-full border border-gray-300 rounded-md focus:outline-none focus:ring focus:border-blue-300"></textarea>
                </div>

                <button type="submit"
                    class="bg-blue-500 text-white p-2 rounded-md hover:bg-blue-600 focus:outline-none focus:ring focus:border-blue-300">
                    Submit
                </button>
            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('resources.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tahsin Abrar\Downloads\education website landing page\resources\views/resources/create.blade.php ENDPATH**/ ?>