
<?php $__env->startSection('auth_content'); ?>
    <div class="flex justify-center items-center h-screen bg-gray-100 ">
        <div class="bg-white rounded-3xl shadow-md w-full sm:w-96 p-12">
            <h2 class="text-2xl font-bold mb-4">Login</h2>

            <?php if($errors->any()): ?>
                <div class="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-2 rounded-md">
                    <strong>Error!</strong> Please fix the following issues:
                    <ul class="mt-2 list-disc list-inside">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>


            <!-- Laravel Form -->
            <form className="w-full" method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <!-- Email Address -->
                <div class="mb-4">
                    <label for="email" class="block text-sm font-medium text-gray-600">Email Address</label>
                    <input type="email" name="email" id="email" class="mt-1 p-2 w-full border rounded-md"
                        value="<?php echo e(old('email')); ?>" required autofocus>

                </div>

                <!-- Password -->
                <div class="mb-4">
                    <label for="password" class="block text-sm font-medium text-gray-600">Password</label>
                    <input type="password" name="password" id="password" class="mt-1 p-2 w-full border rounded-md"
                        required>

                </div>

                <!-- Remember Me -->
                

                <!-- Login Button -->
                <div className=" mb-4">
                    <button type="submit"
                        class="cursor-pointer bg-blue-500 text-white font-bold py-2 px-4 rounded-full hover:bg-blue-600 transition duration-300">
                        Login
                    </button>
                </div>
            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tahsin Abrar\Downloads\education website landing page\resources\views/auth/login.blade.php ENDPATH**/ ?>