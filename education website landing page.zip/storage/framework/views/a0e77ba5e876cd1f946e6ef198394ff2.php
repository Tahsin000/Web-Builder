
<?php $__env->startSection('title'); ?>
    <?php echo $resource->router; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <?php echo $resource->css; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <?php echo $resource->html; ?>

    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <?php echo $resource->script; ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('resources.publish', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Tahsin Abrar\Downloads\education website landing page\resources\views/resources/show.blade.php ENDPATH**/ ?>